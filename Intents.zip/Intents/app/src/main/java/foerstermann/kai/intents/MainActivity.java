package foerstermann.kai.intents;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;

import androidx.annotation.NonNull;

public class MainActivity extends Activity {

    Button btnDialer, btnCall, btnBrowser;
    MainActivityListener mainActivityListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.mainactivity_layout);

        mainActivityListener = new MainActivityListener(this);

        btnDialer = findViewById(R.id.btnDialer);
        btnCall = findViewById(R.id.btnCall);
        btnBrowser = findViewById(R.id.btnBrowser);

        btnDialer.setOnClickListener(mainActivityListener);
        btnCall.setOnClickListener(mainActivityListener);
        btnBrowser.setOnClickListener(mainActivityListener);


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        mainActivityListener.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }



}
